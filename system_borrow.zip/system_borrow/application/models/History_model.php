<?php

class History_model extends CI_Model
{


    public function getAllHistory()
    {
        return $this->db->query("SELECT * FROM tbl_history")->result_array();
    }
}
