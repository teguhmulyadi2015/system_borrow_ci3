<?php

class Barang_model extends CI_Model
{


    public function getAllFdStatus1()
    {
        $status = 1;
        $query = $this->db->get_where('tbl_barang', array('status' => $status));

        return $query->result_array();
    }
}
