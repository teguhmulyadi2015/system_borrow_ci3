<?php

class Orang_model extends CI_Model
{


    public function getDataOrang($nik)
    {
        $query = $this->db->get_where('tbl_orang', array('nik' => $nik));
        return $query->row_array();
    }
}
