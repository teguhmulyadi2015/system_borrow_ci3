<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Borrow extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model');
        $this->load->model('Orang_model');
    }
    public function index()
    {

        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('borrow/borrow');
        $this->load->view('templates/footer');
    }

    public function borrowFd()
    {
        $data['borrowfd'] = $this->Barang_model->getAllFdStatus1();

        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('borrow/borrow-fd', $data);
        $this->load->view('templates/footer');
    }

    public function autocomplete()
    {
        // $nik = $this->input->get('nik');
        $nik = $_GET['nik'];
        // $nik = $this->input->post('nik', true);
        $cari = $this->Orang_model->getDataOrang($nik);

        if ($cari) {
            echo json_encode($cari);
        } else {
            echo json_encode(array('error' => 'No rows, or there was more than one row'));
        }
    }
}
