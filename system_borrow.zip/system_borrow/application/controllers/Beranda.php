<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Beranda extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('History_model');
    }
    public function index()
    {
        $data['history'] = $this->History_model->getAllHistory();

        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('borrow/beranda', $data);
        $this->load->view('templates/footer');
    }
}
