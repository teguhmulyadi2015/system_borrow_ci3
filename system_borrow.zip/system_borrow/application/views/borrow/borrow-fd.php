<!-- Begin page content -->
<main role="main" class="flex-shrink-0">
    <div class="container">
        <!-- <h1>Sticky footer with fixed navbar</h1> -->
        <h1 class="mt-5">Borrow Flashdisk</h1>
        <a href="<?= base_url('borrow/index') ?>" class="btn btn-primary mb-2">Kembali</a>
        <div class="row">
            <div class="col-md">
                <form action="">
                    <div class="form-group">
                        <label for="nik"><b>NIK</b></label>

                        <input type="text" class="form-control" name="nik" id="nik" onkeyup="isi_otomatis()" autofocus>

                    </div>
                    <div class="form-group">
                        <label for="nama"><b>Nama</b></label>
                        <input type="text" class="form-control" name="nama" id="nama" readonly>
                    </div>
                    <div class="form-group">
                        <label for="flashdisk"><b>Flashdisk</b></label>
                        <?php if ($borrowfd) : ?>
                            <?php foreach ($borrowfd as $bf) : ?>
                                <div class="col-md ml-2">
                                    <input class="form-check-input" type="radio" value="<?= $bf['id'] ?>" name="fd">
                                    <label class="form-check-label">
                                        <?php echo $bf['kode_barang'] . "-" . $bf['nama_barang']; ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <!-- <div class="col-sm-4">
                            <input class="form-control-check-input" type="checkbox" value="">
                            <label class="form-check-label" for="defaultCheck1">
                                F01 - Flashdisk Kingston 128 GB
                            </label>
                        </div>-->
                    </div>

                    <div class="form-group">

                        <input type="submit" class="btn btn-primary" value="submit">

                    </div>
                </form>
            </div>
        </div>


    </div>
</main>