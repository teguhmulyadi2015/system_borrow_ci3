<!-- Begin page content -->
<main role="main" class="flex-shrink-0">
    <div class="container">
        <!-- <h1>Sticky footer with fixed navbar</h1> -->
        <h1 class="mt-5">List Data Borrow</h1>

        <a href="<?= base_url('beranda') ?>" class="btn btn-primary mb-2">Kembali</a>
        <div class="row">
            <div class="col">
                <table class="table">

                    <tr>

                        <td>
                            <center>
                                <div class="card" style="width: 18rem;">
                                    <a href="<?= base_url('borrow/borrowfd') ?>">
                                        <img src="<?= base_url('assets/image/fd.jpg') ?>" class="card-img-top" width="500px" height="300px">
                                        <div class="card-body">
                                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                        </div>
                                    </a>
                                </div>
                            </center>
                        </td>
                        <td>
                            <center>
                                <div class="card" style="width: 18rem;">
                                    <img src="<?= base_url('assets/image/laptop.webp') ?>" class="card-img-top" width="500px" height="300px">
                                    <div class="card-body">
                                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    </div>
                                </div>
                            </center>
                        </td>

                    </tr>

                </table>
            </div>
        </div>

    </div>
</main>