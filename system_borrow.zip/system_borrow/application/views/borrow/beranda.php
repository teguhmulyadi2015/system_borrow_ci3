<!-- Begin page content -->
<main role="main" class="flex-shrink-0">
    <div class="container">
        <!-- <h1>Sticky footer with fixed navbar</h1> -->
        <h1 class="mt-5">Sytem Borrow</h1>

        <a href="<?= base_url('borrow/index') ?>" class="btn btn-primary mb-2">Pinjam</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">NIK</th>
                    <th scope="col">Nama Barang</th>
                    <th scope="col">Waktu Pinjam</th>
                    <th scope="col">Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($history as $h) : ?>
                    <tr>
                        <th scope="row">1</th>
                        <td><?= $h['nik'] ?></td>
                        <td><?= 'a' ?></td>
                        <td><?= 'a' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>