<footer class="footer mt-auto py-3">
    <div class="container">
        <span class="text-muted">Place sticky footer content here.</span>
    </div>
</footer>



<script src="<?= base_url() ?>/assets/dist/js/jquery.min.js"></script>
<script src="<?= base_url() ?>/assets/dist/js/bootstrap.bundle.min.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->

<script>
    function isi_otomatis() {
        var nik = $("#nik").val();
        $.ajax({
            url: '<?= base_url('borrow/autocomplete') ?>',
            data: {
                'nik': nik
            },
            // method: 'GET'
        }).success(function(data) {
            var json = data,
                obj = JSON.parse(json);
            $('#nama').val(obj.nama);
        });
    }
</script>
</body>

</html>